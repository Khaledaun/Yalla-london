
import { EnhancedAdminDashboard } from '@/components/admin/enhanced-admin-dashboard'

export default function AdminPage() {
  return <EnhancedAdminDashboard />
}
