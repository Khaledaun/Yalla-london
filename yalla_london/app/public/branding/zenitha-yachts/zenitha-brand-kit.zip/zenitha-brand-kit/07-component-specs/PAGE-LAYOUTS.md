# Zenitha Yachts — Page Layout Specifications

## Hero Section

```
┌──────────────────────────────────────────────────────────┐
│                                                          │
│  [Full-bleed yacht image, golden hour, 100vh]            │
│  ┌──────────────────────────────────────────┐            │
│  │                                          │            │
│  │ ── LUXURY YACHT CHARTER ──               │ ← overline│
│  │                                          │            │
│  │ Sail the World's Most                    │ ← h1      │
│  │ Beautiful Coastlines                     │            │
│  │                                          │            │
│  │ Private charters across the              │ ← body    │
│  │ Mediterranean, Arabian Gulf & beyond.    │            │
│  │                                          │            │
│  │ [Plan Your Charter →] [Browse Fleet]     │ ← CTAs    │
│  │                                          │            │
│  └──────────────────────────────────────────┘            │
│                    ⌄ SCROLL                              │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Height         | 100vh (desktop), 75vh (mobile)                 |
| Background     | Full-bleed image, `var(--z-gradient-image)` overlay |
| Overline       | DM Sans 600, 11px, gold, 0.18em, uppercase    |
| H1             | Playfair Display 700, 72px→40px, white, -0.02em |
| Subtitle       | Source Sans 3 300, 16px, white/65, max-w 440px |
| Primary CTA    | Gold bg, navy text, 14px DM Sans 600           |
| Secondary CTA  | Transparent, white/30 border                   |
| Scroll indicator| Chevron, fade animation, bottom 20px           |
| Animation      | Overline: `.z-fade-up-d0`, H1: `.z-fade-up-d1`, Body: `.z-fade-up-d2`, CTAs: `.z-fade-up-d3` |

---

## Trust Bar

```
┌──────────────────────────────────────────────────────────┐
│  200+ Yachts   ·   15 Destinations   ·   4.9★   ·  100% │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Background     | White, subtle card shadow                      |
| Padding        | 16px 24px                                      |
| Stat value     | JetBrains Mono 500, 18px, navy                 |
| Stat label     | DM Sans 400, 10px, muted, 0.05em              |
| Animation      | `.z-counter-up` with stagger d0–d3             |

---

## How It Works (3 Steps)

```
┌──────────────────────────────────────────────────────────┐
│ bg: Sand                                                 │
│ ── HOW IT WORKS ──                                       │
│ Charter Made Simple                                      │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│  │ 01       │  │ 02       │  │ 03       │              │
│  │ Tell Us  │  │ We Curate│  │ Set Sail │              │
│  │ Your     │  │ Your     │  │          │              │
│  │ Dream    │  │ Charter  │  │          │              │
│  │          │  │          │  │          │              │
│  │ desc...  │  │ desc...  │  │ desc...  │              │
│  └──────────┘  └──────────┘  └──────────┘              │
│                                                          │
│             [Start Planning →]                           │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Background     | `var(--z-sand)` / `#F5EDE0`                    |
| Overline       | Gold, 11px, 0.15em                             |
| H2             | DM Sans 600, 26px, navy                        |
| Step number    | JetBrains Mono 500, 28px, gold/40              |
| Step title     | DM Sans 600, 16px, navy                        |
| Step desc      | Source Sans 3 400, 14px, gray, 1.6 lh          |
| Grid           | 3 columns, 20px gap                            |
| Animation      | Steps: `.z-fade-up` with stagger d0–d2         |

---

## Testimonials

```
┌──────────────────────────────────────────────────────────┐
│ bg: Navy                                                 │
│ ── TESTIMONIALS ──                                       │
│ What Our Guests Say                                      │
│                                                          │
│  ┌─────────────────────┐  ┌─────────────────────┐       │
│  │ " (gold, large)     │  │ " (gold, large)     │       │
│  │ Quote text...       │  │ Quote text...       │       │
│  │                     │  │                     │       │
│  │ ★★★★★             │  │ ★★★★★             │       │
│  │ Name · Destination  │  │ Name · Destination  │       │
│  └─────────────────────┘  └─────────────────────┘       │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Background     | `var(--z-navy)`                                |
| Card bg        | `var(--z-midnight)`                            |
| Quote mark     | Playfair Display, 36px, gold/30                |
| Quote text     | Source Sans 3 400, 14px, white/75, 1.65 lh     |
| Stars          | 12px, gold / white/20                          |
| Name           | DM Sans 600, 13px, white                       |
| Destination    | Source Sans 3, 11px, champagne                 |

---

## Pricing Tiers

```
┌──────────────────────────────────────────────────────────┐
│ ── CHARTER OPTIONS ──                                    │
│ Choose Your Experience                                   │
│                                                          │
│  ┌──────────┐  ┌──────────────┐  ┌──────────┐          │
│  │ Sailing  │  │ ★MOST POP.★ │  │ Motor    │          │
│  │ Yacht    │  │ Catamaran    │  │ Yacht    │          │
│  │          │  │              │  │          │          │
│  │ €3,000   │  │ €5,200       │  │ €8,000   │          │
│  │ /week    │  │ /week        │  │ /week    │          │
│  │          │  │              │  │          │          │
│  │ ✓ feat   │  │ ✓ feat       │  │ ✓ feat   │          │
│  │ ✓ feat   │  │ ✓ feat       │  │ ✓ feat   │          │
│  │          │  │              │  │          │          │
│  │[View →]  │  │[View Fleet→] │  │[View →]  │          │
│  └──────────┘  └──────────────┘  └──────────┘          │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Popular card   | 2px gold border, gold shadow                   |
| Popular badge  | Gold bg, navy text, 9px, rounded-full, -10px top |
| Tier name      | DM Sans 600, 16px, navy                        |
| Price          | JetBrains Mono 500, 20px, gold                 |
| Period         | Source Sans 3, 11px, muted                     |
| Features       | Source Sans 3 400, 13px, `✓` in mediterranean  |
| Popular CTA    | Gold bg, navy text, full width                 |
| Other CTA      | Aegean border, aegean text, full width         |

---

## Newsletter Section

```
┌──────────────────────────────────────────────────────────┐
│ bg: Sand → Champagne gradient                            │
│              Receive Exclusive Charter Offers             │
│          First access to new yachts and deals.           │
│                                                          │
│         [your@email.com         ] [Subscribe]            │
│          We respect your privacy.                        │
└──────────────────────────────────────────────────────────┘
```

| Element        | Spec                                           |
|----------------|------------------------------------------------|
| Background     | `linear-gradient(135deg, sand, champagne)`     |
| H3             | DM Sans 600, 22px, navy, center                |
| Subtitle       | Source Sans 3, 14px, gray, center              |
| Input          | Source Sans 3, 14px, champagne border, white bg |
| Button         | Gold bg, navy text, DM Sans 600, 13px          |
| Privacy note   | Source Sans 3, 11px, muted                     |

---

## Footer

```
┌──────────────────────────────────────────────────────────┐
│ bg: Navy                                                 │
│ ZENITHA YACHTS                                           │
│ Curated yacht charters for discerning travelers.         │
│ ━━━━━━━━━━━ ━━━━ ━━ (tri-color bar)                     │
│                                                          │
│ DESTINATIONS    CHARTER       COMPANY      CONNECT       │
│ Greek Islands   Browse Yachts About Us     Email         │
│ Croatian Coast  AI Planner    How It Works WhatsApp      │
│ Turkish Riviera Inquiry Form  Blog         Instagram     │
│ Arabian Gulf    Itineraries   FAQ          LinkedIn      │
│ Red Sea         Charter Types Contact                    │
│                                                          │
│────────────────────────────────────────────────────────── │
│ © 2026 Zenitha.Luxury LLC          EN | AR | Halal ✓    │
└──────────────────────────────────────────────────────────┘
```

| Element          | Spec                                          |
|------------------|-----------------------------------------------|
| Background       | `var(--z-navy)`                               |
| Logo             | Playfair 700 20px white + DM Sans 300 9px gold |
| Tagline          | Source Sans 3, 13px, white/40                  |
| Accent bar       | Gold + Champagne + Ocean, 2px                  |
| Column heading   | DM Sans 600, 10px, gold, 0.12em tracking       |
| Column link      | Source Sans 3, 12px, white/50                   |
| Divider          | 1px solid white/8                               |
| Copyright        | Source Sans 3, 11px, white/25                   |
| Grid             | 4 columns, 20px gap                            |

---

## Responsive Behavior

### Mobile (< 640px)
- Hero: 75vh, text centered, stacked CTAs
- Navigation: Hamburger → full drawer from right
- Yacht cards: 1 per row, full width
- Pricing: Stack vertically
- Footer: 2×2 grid → single column
- Sticky bottom CTA bar: 64px, white bg, price + button
- Touch targets: Min 44×44px

### Tablet (640–1023px)
- Hero: 85vh
- Yacht cards: 2 per row
- Pricing: 3 columns (compressed)
- Footer: 4 columns
- Sidebar filters: Collapse to chips or bottom sheet
