# Zenitha Yachts — Brand Kit

**Maritime Luxury · Refined · Confident · Worldly**

Generated: February 2026 | Prepared for: Khaled N. Aun, Zenitha.Luxury LLC

---

## Quick Start

### 1. Import Fonts

```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;700&family=DM+Sans:wght@300;400;500;600;700&family=Source+Sans+3:wght@300;400;600&family=JetBrains+Mono:wght@400;500&family=IBM+Plex+Sans+Arabic:wght@300;400;500;700&display=swap" rel="stylesheet">
```

### 2. Import Design Tokens

```html
<link rel="stylesheet" href="zenitha-tokens.css">
```

### 3. Import Animations

```html
<link rel="stylesheet" href="zenitha-animations.css">
```

### 4. Apply Classes

```html
<div class="z-fade-up">Content reveals upward</div>
<button class="z-glow">CTA with gold glow</button>
<div class="z-hover-lift">Card with hover lift</div>
```

### 5. Use Design Tokens

```css
.my-heading {
  font-family: var(--z-font-display);
  font-size: var(--z-size-h1);
  color: var(--z-text-primary);
  letter-spacing: var(--z-ls-heading);
}
```

---

## Font Stack

| Role     | Font                   | Weights       | Use                              |
|----------|------------------------|---------------|----------------------------------|
| Display  | Playfair Display       | 400, 500, 700 | Hero headlines, yacht names      |
| Headings | DM Sans                | 300–700       | H2–H6, nav, UI labels, cards    |
| Body     | Source Sans 3          | 300, 400, 600 | Paragraphs, descriptions, forms  |
| Arabic   | IBM Plex Sans Arabic   | 300–700       | All Arabic text                  |
| Mono     | JetBrains Mono         | 400, 500      | Prices, specs, reference numbers |

---

## Color Palette

### Primary — Deep Maritime
| Name     | Hex       | Use                              |
|----------|-----------|----------------------------------|
| Navy     | `#0A1628` | Primary backgrounds, headings    |
| Midnight | `#1B2A4A` | Section backgrounds, cards       |
| Aegean   | `#2E5A88` | Links, interactive elements      |
| Ocean    | `#4A90B8` | Hover states, secondary accents  |
| Shallow  | `#7CB8D4` | Decorative, progress bars        |

### Gold & Warm — Luxury Signals
| Name      | Hex       | Use                              |
|-----------|-----------|----------------------------------|
| Gold      | `#C9A96E` | CTAs, highlights, star ratings   |
| Champagne | `#E8D5B5` | Subtle backgrounds, dividers     |
| Sand      | `#F5EDE0` | Card backgrounds, light sections |
| Pearl     | `#FAFAF7` | Page backgrounds                 |
| White     | `#FFFFFF` | Content surfaces, inputs         |

### Accent — Status & Feedback
| Name          | Hex       | Use                      |
|---------------|-----------|--------------------------|
| Mediterranean | `#0EA5A2` | Success, available       |
| Coral         | `#E07A5F` | Warning, limited avail.  |
| Storm         | `#DC2626` | Error (sparingly)        |

---

## Folder Structure

```
zenitha-brand-kit/
├── 01-logos-svg/              12 logo variants with backgrounds
├── 02-logos-transparent/      14 transparent-bg logos + standalone elements
├── 03-social-icons/           6 social media optimized icons
├── 04-brand-elements/         Compass rose + gold accent bar
├── 05-animations/             zenitha-animations.css
├── 06-design-tokens/          zenitha-tokens.css
├── 07-component-specs/        COMPONENT-SPECS.md + PAGE-LAYOUTS.md
└── README.md                  This file
```

---

## Critical Rules

1. **RTL Arabic text**: NEVER apply `letter-spacing` — it breaks Arabic ligatures
2. **Gold accent bar order**: Always Gold (60%) → Champagne (22%) → Ocean (10%)
3. **Backgrounds**: Never use pure `#000000` or `#FFFFFF` — use Navy and Pearl instead
4. **Button text on Gold**: Use Navy text, not White (insufficient contrast)
5. **Overlines**: Always `DM Sans 600`, `12px`, `uppercase`, `letter-spacing: 0.12em`
6. **Display headings**: Always `Playfair Display 700` with `letter-spacing: -0.02em`
7. **Reduced motion**: All animations respect `prefers-reduced-motion: reduce`
8. **Dark mode**: Use `data-theme="dark"` attribute or `.zenitha-dark` class

---

© 2026 Zenitha.Luxury LLC · zenithayachts.com
