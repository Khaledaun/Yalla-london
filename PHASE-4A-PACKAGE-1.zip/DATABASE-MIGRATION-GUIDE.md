
# Phase 4A Database Migration Guide

## 🎯 Overview
This guide provides step-by-step instructions for applying the Phase 4A database extensions to your existing Prisma schema and Supabase database.

## ⚠️ Safety First
- **Additive-only changes**: No existing tables or columns are modified
- **Zero data loss risk**: All changes are purely additive
- **Backward compatible**: Existing functionality remains unchanged
- **Rollback safe**: Can be rolled back by disabling feature flags

## 📊 Changes Summary
- **12 new models added**: TopicProposal, RulebookVersion, PageTypeRecipe, Place, ImageAsset, VideoAsset, AnalyticsSnapshot, SeoAuditResult, Site, SiteTheme, SiteMember
- **Extended existing models**: BlogPost and ScheduledContent get new optional fields
- **Seed data**: 30 London places, 7 page type recipes, 1 initial rulebook

## 🔧 Step-by-Step Migration

### Step 1: Update Prisma Schema
1. **Backup your current schema**:
   ```bash
   cp prisma/schema.prisma prisma/schema.prisma.backup
   ```

2. **Add the new models**:
   Copy the contents from `prisma-schema-additions.prisma` and add them to the end of your existing `prisma/schema.prisma` file.

3. **Extend existing BlogPost model**:
   Add these fields to your existing BlogPost model:
   ```prisma
   // Phase 4+ Extensions (add to existing BlogPost model)
   page_type                String?  // guide, place, event, list, faq, news, itinerary
   keywords_json            Json?    // Primary + long-tail keywords
   questions_json           Json?    // PAA-style questions
   authority_links_json     Json?    // Authority source links used (3-4 links)
   featured_longtails_json  Json?    // EXACTLY 2 featured long-tails
   seo_score                Int?     // SEO audit score (0-100)
   og_image_id              String?  // Reference to generated OG image
   place_id                 String?  // Reference to Place if location-based

   // Add this relation:
   place        Place?   @relation(fields: [place_id], references: [id])

   // Add these indexes:
   @@index([page_type])
   @@index([place_id])
   @@index([seo_score])
   ```

4. **Extend existing ScheduledContent model**:
   Add these fields to your existing ScheduledContent model:
   ```prisma
   // Phase 4+ Extensions (add to existing ScheduledContent model)
   page_type              String?  // guide, place, event, list, faq, news, itinerary
   topic_proposal_id      String?  // Reference to TopicProposal
   seo_score              Int?     // SEO audit score (0-100)
   generation_source      String?  // manual, topic_proposal, discovery_prompt
   authority_links_used   Json?    // Track which authority links were used
   longtails_used         Json?    // Track which long-tails were used

   // Add this relation:
   topic_proposal TopicProposal? @relation(fields: [topic_proposal_id], references: [id])

   // Add these indexes:
   @@index([page_type])
   @@index([topic_proposal_id])
   @@index([seo_score])
   @@index([generation_source])
   ```

### Step 2: Create Migration
```bash
# Create migration file
npx prisma migrate dev --name "phase4a-initial-models" --create-only

# Review the generated migration
ls -la prisma/migrations/

# Apply migration to local development database (if applicable)
npx prisma migrate dev

# Generate fresh Prisma client
npx prisma generate
```

### Step 3: Apply to Supabase Staging
```bash
# Set your staging database URL
export DATABASE_URL="your-staging-supabase-url"

# Apply migration to staging
npx prisma migrate deploy

# Verify migration applied
npx prisma migrate status
```

### Step 4: Run Seed Data
```bash
# Copy seed script to your scripts folder
cp seed-phase4a-initial.ts scripts/

# Run seeds (idempotent - safe to run multiple times)
npx tsx scripts/seed-phase4a-initial.ts
```

### Step 5: Verification
```sql
-- Connect to your Supabase database and run these checks:

-- 1. Verify all new tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('TopicProposal', 'RulebookVersion', 'PageTypeRecipe', 'Place', 'ImageAsset', 'VideoAsset', 'AnalyticsSnapshot', 'SeoAuditResult', 'Site', 'SiteTheme', 'SiteMember');

-- 2. Check BlogPost extensions
SELECT column_name, data_type FROM information_schema.columns 
WHERE table_name = 'BlogPost' 
AND column_name IN ('page_type', 'keywords_json', 'authority_links_json', 'seo_score', 'place_id');

-- 3. Verify seed data
SELECT COUNT(*) as place_count FROM "Place"; -- Should be 30
SELECT COUNT(*) as recipe_count FROM "PageTypeRecipe"; -- Should be 7
SELECT version, is_active FROM "RulebookVersion"; -- Should show 2024.09.1 as active
```

### Step 6: Test Application
```bash
# Ensure your application builds successfully
yarn build

# Run development server
yarn dev

# Verify no TypeScript errors
yarn type-check
```

## 🧪 Testing Checklist

### Database Tests
- [ ] Migration applies cleanly to Supabase
- [ ] All 12 new tables created successfully
- [ ] BlogPost and ScheduledContent models extended
- [ ] 30 places seeded (verify count)
- [ ] 7 page type recipes seeded (verify count)
- [ ] 1 active rulebook version (2024.09.1)
- [ ] Seed script is idempotent (can run multiple times)

### Application Tests
- [ ] Application builds without errors (`yarn build`)
- [ ] TypeScript compilation succeeds
- [ ] Existing functionality unchanged
- [ ] Prisma client generation successful
- [ ] No runtime errors when accessing database

### Feature Flag Tests
- [ ] All Phase 4A features remain disabled (flags OFF)
- [ ] No behavioral changes in existing features
- [ ] Database models accessible via Prisma client

## 🚨 Rollback Procedures

### Level 1: Disable Features (Recommended)
```bash
# All Phase 4A features are disabled by default via feature flags
# No action needed unless you've enabled them
```

### Level 2: Revert Schema (Data Loss!)
```sql
-- WARNING: This will delete all Phase 4A data!
-- Only use if absolutely necessary

DROP TABLE IF EXISTS "SiteMember";
DROP TABLE IF EXISTS "SiteTheme"; 
DROP TABLE IF EXISTS "Site";
DROP TABLE IF EXISTS "SeoAuditResult";
DROP TABLE IF EXISTS "AnalyticsSnapshot";
DROP TABLE IF EXISTS "VideoAsset";
DROP TABLE IF EXISTS "ImageAsset";
DROP TABLE IF EXISTS "Place";
DROP TABLE IF EXISTS "PageTypeRecipe";
DROP TABLE IF EXISTS "RulebookVersion";
DROP TABLE IF EXISTS "TopicProposal";

-- Remove added columns (reversible)
ALTER TABLE "BlogPost" 
DROP COLUMN IF EXISTS page_type,
DROP COLUMN IF EXISTS keywords_json,
DROP COLUMN IF EXISTS questions_json,
DROP COLUMN IF EXISTS authority_links_json,
DROP COLUMN IF EXISTS featured_longtails_json,
DROP COLUMN IF EXISTS seo_score,
DROP COLUMN IF EXISTS og_image_id,
DROP COLUMN IF EXISTS place_id;

ALTER TABLE "ScheduledContent"
DROP COLUMN IF EXISTS page_type,
DROP COLUMN IF EXISTS topic_proposal_id,
DROP COLUMN IF EXISTS seo_score,
DROP COLUMN IF EXISTS generation_source,
DROP COLUMN IF EXISTS authority_links_used,
DROP COLUMN IF EXISTS longtails_used;
```

### Level 3: Restore from Backup
```bash
# Restore from schema backup
cp prisma/schema.prisma.backup prisma/schema.prisma

# Create revert migration
npx prisma migrate dev --name "revert-phase4a"

# Apply to databases
npx prisma migrate deploy
```

## ✅ Success Criteria

### Migration Success
- [ ] All tables created in Supabase
- [ ] Migration status shows "Applied"
- [ ] No foreign key constraint errors
- [ ] Seed data loaded successfully

### Application Success  
- [ ] Build completes without errors
- [ ] Existing features work unchanged
- [ ] New models accessible via Prisma
- [ ] TypeScript types generated correctly

### Data Integrity Success
- [ ] Existing data preserved
- [ ] New tables properly indexed
- [ ] Foreign key relationships valid
- [ ] Seed data is correctly structured

## 📞 Support

If you encounter issues during migration:

1. **Check migration logs**: Look for specific error messages in migration output
2. **Verify Supabase permissions**: Ensure your database user has CREATE TABLE privileges
3. **Check constraints**: Foreign key and unique constraints may conflict
4. **Rollback safely**: Use feature flags first, schema revert as last resort

## 🎯 Next Steps

After successful database migration:
1. Proceed with **Package 2: Feature Flags Extensions**
2. All Phase 4A features remain disabled until flags are enabled
3. Test feature enablement on staging environment first
4. Monitor for any performance impact with new indexes

---

**Migration Status**: Ready for implementation  
**Risk Level**: 🟢 Low (additive-only)  
**Data Safety**: ✅ Zero data loss risk  
**Rollback**: ✅ Multiple safe options available
