# Zenitha Yachts — Brand Assets Package

**Owner:** Zenitha.Luxury LLC  
**Version:** 1.0 — April 2026  
**Canva Source:** Design ID `DAHGGp9AUgQ`

---

## Contents

### Vector Assets (SVG)
| File | Description |
|------|-------------|
| `zenitha-logo.svg` | Full 2×2 logo system (all 4 lockups) |
| `logo-compass-gold-navy.svg` | Gold compass rose on navy — primary mark |
| `logo-compass-dark-cream.svg` | Dark compass rose on cream |
| `logo-anchor-gold-navy.svg` | Gold anchor on navy |
| `logo-anchor-dark-cream.svg` | Dark anchor on cream |

### Raster & Print
| File | Description |
|------|-------------|
| `zenitha-logo-4k.png` | 4000×4000px, transparent background |
| `zenitha-logo.pdf` | Print-ready PDF export |

### Brand Guidelines
| File | Description |
|------|-------------|
| `zenitha-yachts-brand-spec.html` | Full branding spec (open in browser) |

---

## Brand Colors

| Name | Hex | Usage |
|------|-----|-------|
| Dark Navy | `#0F1621` | Primary backgrounds |
| Royal Gold | `#C49A2A` | Accent, luxury signifier |
| Parchment | `#F5F0E6` | Light backgrounds |
| Charcoal | `#1E1E1E` | Text & marks on light |
| Light Gold | `#D4AF5A` | Secondary accent |

## Typography

- **Display/Branding:** Cinzel (Regular, Medium, Semibold)
- **Body:** Cormorant Garamond
- **UI/Labels:** Montserrat (Light, Regular)

## Logo Marks

Two primary marks alternate across colorways:
1. **Compass Rose** — 8-pointed ornate star
2. **Anchor** — Classic nautical anchor

### Approved Colorways
- Gold (#C49A2A) on Dark Navy (#0F1621)
- Charcoal (#1E1E1E) on Parchment (#F5F0E6)

### Rules
- Never place gold and navy adjacent without a neutral separator
- Maintain clear space equal to the "Y" height in YACHTS
- Minimum digital size: 40px width
- Minimum print size: 12mm width
- Do not rotate, stretch, distort, or apply effects

---

## Source

All SVG files were converted from the Canva PDF export using `pdftocairo`.  
Original Canva design: `Copy of Zenitha` (saved as template in Zenitha LLC team).

---

*Zenitha.Luxury LLC — Confidential*
