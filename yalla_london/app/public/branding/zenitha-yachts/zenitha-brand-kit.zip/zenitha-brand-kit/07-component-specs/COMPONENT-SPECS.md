# Zenitha Yachts — Component Specifications

## Buttons

### Primary (Gold CTA)
| Property        | Value                                    |
|-----------------|------------------------------------------|
| Background      | `var(--z-gold)` / `#C9A96E`              |
| Text color      | `var(--z-navy)` / `#0A1628`              |
| Font            | DM Sans 600, 15px                        |
| Letter spacing  | 0.01em                                   |
| Padding         | 12px 28px (md), 8px 16px (sm), 16px 36px (lg) |
| Border radius   | 8px                                      |
| Hover           | Darken 8%, `box-shadow: var(--z-shadow-gold)` |
| Active          | Darken 12%                               |
| Animation       | `.z-glow` for high-impact CTAs           |

### Secondary (Navy Outline)
| Property        | Value                                    |
|-----------------|------------------------------------------|
| Background      | transparent                              |
| Border          | 1.5px solid `var(--z-navy)`              |
| Text color      | `var(--z-navy)`                          |
| Font            | DM Sans 500, 15px                        |
| Hover           | Navy fill, white text                    |

### Ghost (Text Link)
| Property        | Value                                    |
|-----------------|------------------------------------------|
| Background      | transparent                              |
| Text color      | `var(--z-aegean)` / `#2E5A88`            |
| Font            | DM Sans 500, 15px                        |
| Hover           | Underline, darken 10%, arrow shifts 4px right |

---

## Badges / Tags

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Font            | DM Sans 600, 11px                        |
| Letter spacing  | 0.04em                                   |
| Padding         | 4px 10px                                 |
| Border radius   | 4px                                      |
| Text transform  | uppercase                                |

### Badge Colors
| Type            | Background         | Text              |
|-----------------|--------------------|-------------------|
| Category        | `var(--z-aegean)`  | white             |
| Halal           | `var(--z-mediterranean)` | white       |
| Premium         | `var(--z-midnight)`| white             |
| Family          | `var(--z-ocean)`   | white             |
| Urgent          | `var(--z-coral)`   | white             |
| New / Featured  | `var(--z-gold)`    | navy              |

---

## Form Inputs

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Font            | Source Sans 3 400, 15px                  |
| Color           | `var(--z-navy)`                          |
| Padding         | 10px 14px                                |
| Border radius   | 8px                                      |
| Border          | 1.5px solid `var(--z-champagne)`         |
| Focus border    | `var(--z-aegean)` + subtle gold shadow   |
| Error border    | `var(--z-coral)`                         |
| Error text      | Source Sans 3 400, 12px, `var(--z-coral)` |

### Label
| Property        | Value                                    |
|-----------------|------------------------------------------|
| Font            | DM Sans 500, 12px                        |
| Color           | `#6B7280`                                |
| Margin bottom   | 6px                                      |

---

## Yacht Card

```
┌─────────────────────────────┐
│ [4:3 Image]                 │
│ ┌──────┐        ┌──────┐   │
│ │ TYPE │        │ HALAL│   │
│ └──────┘        └──────┘   │
├─────────────────────────────┤
│ Yacht Name                  │ ← DM Sans 600, 17px, navy
│ Specs · Specs · Specs       │ ← Source Sans 3, 13px, gray
│                             │
│ From €X,XXX /week           │ ← JetBrains Mono 500, 15px, gold
│ ★★★★★ 4.8 (23)            │ ← Gold stars, gray count
│─────────────────────────────│
│ View Details →              │ ← DM Sans 500, 14px, aegean
└─────────────────────────────┘
```

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Border radius   | 12px                                     |
| Shadow          | `var(--z-shadow-card)`                   |
| Hover shadow    | `var(--z-shadow-hover)`                  |
| Image aspect    | 4:3, object-fit: cover                   |
| Image hover     | scale(1.03), 350ms ease                  |
| Animation       | `.z-hover-lift`                          |

---

## Destination Card

```
┌─────────────────────────────────────┐
│                                     │
│ [Panoramic with gradient overlay]   │
│                                     │
│ DESTINATION NAME                    │ ← DM Sans 600, 22px, white
│ Season · From €X,XXX/wk            │ ← Source Sans 3, 14px, champagne
│ XX yachts available                 │ ← Source Sans 3, 13px, white/50
└─────────────────────────────────────┘
```

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Border radius   | 12px                                     |
| Overlay         | `var(--z-gradient-image)`                |
| Hover           | Image parallax lift, overlay lightens    |

---

## Toast Notifications

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Border radius   | 8px                                      |
| Background      | white                                    |
| Shadow          | `var(--z-shadow-elevated)`               |
| Border left     | 4px solid [status color]                 |
| Icon size       | 28px circle                              |
| Title font      | DM Sans 600, 13px                        |
| Message font    | Source Sans 3 400, 13px                  |
| Animation       | `.z-slide-up`                            |

### Toast Status Colors
| Type    | Color               |
|---------|---------------------|
| Success | `var(--z-mediterranean)` |
| Info    | `var(--z-aegean)`   |
| Warning | `var(--z-gold)`     |
| Error   | `var(--z-coral)`    |

---

## Navigation Bar

| Property        | Light Mode             | Dark Mode              |
|-----------------|------------------------|------------------------|
| Height          | 64px (scrolled) / 80px | 64px (scrolled) / 80px |
| Background      | white                  | navy                   |
| Shadow          | card (on scroll)       | none                   |
| Logo            | Playfair 700 18px navy | Playfair 700 18px white|
| Links           | DM Sans 500 13px gray  | DM Sans 500 13px white/70 |
| CTA             | Gold bg, navy text     | Gold bg, navy text     |
| Link hover      | Gold underline slides in from left, 250ms |

---

## Footer

| Property        | Value                                    |
|-----------------|------------------------------------------|
| Background      | `var(--z-navy)`                          |
| Padding         | 32px                                     |
| Column titles   | DM Sans 600, 10px, gold, 0.12em tracking |
| Column links    | Source Sans 3 400, 12px, white/50        |
| Copyright       | Source Sans 3, 11px, white/25            |
| Accent bar      | Gold(60%) + Champagne(22%) + Ocean(10%)  |

---

## Tri-Color Accent Bar

Always rendered in this exact order:
1. **Gold** `#C9A96E` — 60% of total width
2. **Champagne** `#E8D5B5` — 22% of total width (gap: 4% between)
3. **Ocean** `#4A90B8` — 10% of total width (gap: 4% between)

Height: 2-3px. Border radius: 1px per segment.

---

## Spacing Scale

| Token       | Value  | Use                          |
|-------------|--------|------------------------------|
| space-1     | 4px    | Icon gaps, inline padding    |
| space-2     | 8px    | Tight element spacing        |
| space-3     | 12px   | Form field gaps              |
| space-4     | 16px   | Card internal padding        |
| space-5     | 20px   | Component gaps               |
| space-6     | 24px   | Section sub-spacing          |
| space-8     | 32px   | Card padding, group spacing  |
| space-10    | 40px   | Between content blocks       |
| space-12    | 48px   | Section padding (mobile)     |
| space-16    | 64px   | Section padding (tablet)     |
| space-20    | 80px   | Section padding (desktop)    |
| space-24    | 96px   | Major section gaps           |

---

## RTL Rules (Arabic)

- All Arabic text uses IBM Plex Sans Arabic
- Letter spacing: ALWAYS 0 (breaks Arabic ligatures)
- Line height: increase ~10% vs English equivalent
- Numerals: Use `Intl.NumberFormat('ar-SA')` for Arabic-Indic numerals
- Direction: `dir="rtl"` on container
- Layout: Mirror all directional elements (arrows, chevrons, sidebar)
- CSS: Use logical properties (`margin-inline-start` not `margin-left`)
